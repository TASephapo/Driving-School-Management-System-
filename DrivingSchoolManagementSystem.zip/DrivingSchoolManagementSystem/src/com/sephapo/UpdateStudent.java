package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class UpdateStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		Connection con;
		String  Student_id= request.getParameter("student_id");
		PrintWriter out = response.getWriter();
		
		try {
			
			
			 con = DatabaseConnection.initializeDatabase();
			
			
			
			String sql = "update student set Student_name=?, surname=?, date_birth=?, Password=?, Fee=? where student_id='"+Student_id+"'";
			
			PreparedStatement st = con.prepareStatement(sql);
			
			st.setString(1, (request.getParameter("student_name")));
			st.setString(2, (request.getParameter("surname")));
			st.setString(3, (request.getParameter("date_birth")));
			st.setString(4, (request.getParameter("Password")));
			st.setString(5, (request.getParameter("Fee")));
			
			

			st.executeUpdate();
			
			//Close all DB connections
			st.close();
	
			
			 out.println("<html>");
			 out.println("<script language= 'javascript'>");
             out.println(" alert('Student is successfully Updated!')");
             out.println(" </script>");
             out.println("<meta http-equiv='refresh' content='0; URL=AdminDashboard.jsp'>");
             out.println("<meta name='keywords' content='automatic redirection'>");
             out.println("</html>");
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			 
			 out.println("<html>");
			  out.println("<script language= 'javascript'>");
             out.println(" alert('Student is not Updated please try again')");
             out.println(" </script>");
             out.println("<meta http-equiv='refresh' content='0; URL=AdminDashboard.jsp'>");
             out.println("<meta name='keywords' content='automatic redirection'>");
             out.println("</html>");					
             e.printStackTrace();
		}
		
		
	}
}


