package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AdminAssignFourWheelTutor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
		
		 
		 String student_id = request.getParameter("student_id");
	    
		
		//initialize connection DB
		
		  Connection con;
		  try 
		   {
					  con = DatabaseConnection.initializeDatabase();
					
						
					    PreparedStatement st = con.prepareStatement("insert into assigntutor values (default,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS); 
					   
					 	 
						st.setString(1, (student_id));
						st.setString(2, (request.getParameter("tutor_id")));
						st.setString(3, (request.getParameter("startDate")));
						st.setString(4, (request.getParameter("EndDate")));
						st.setString(5, (request.getParameter("Time")));
						st.setString(6, (request.getParameter("vehicle_type")));
						
						st.executeUpdate();
						ResultSet tablekeys = st.getGeneratedKeys();
						tablekeys.next();
						st.close();
						
						String status = "assigned"; 
						String sql1 = "update student set status=? where student_id ='"+student_id+"'";
						PreparedStatement st2 = con.prepareStatement(sql1);
						st2.setString(1, (status));
						st2.executeUpdate();
						st2.close();
							
						
					
						   out.println("<html>");
						   out.println("<script language= 'javascript'>");
			               out.println(" alert('Tutor is successfully assigned')");
			               out.println(" </script>");
			               out.println("<meta http-equiv='refresh' content='0; URL=AdminDashboard.jsp'>");
			               out.println("<meta name='keywords' content='automatic redirection'>");
			               out.println("</html>");
						  
					  
				  }
				  catch (ClassNotFoundException e) 
				  {
						e.printStackTrace();
				  }
				   catch (SQLException e) 
				  {
					  
					  out.println("<html>");
					  out.println("<script language= 'javascript'>");
		              out.println(" alert('Tutor is not assigned please try again')");
		              out.println(" </script>");
		              out.println("<meta http-equiv='refresh' content='0; URL=AdminDashboard.jsp'>");
		              out.println("<meta name='keywords' content='automatic redirection'>");
		              out.println("</html>");					
		              e.printStackTrace();
					}
				
				
				
			}
		
		
	}


