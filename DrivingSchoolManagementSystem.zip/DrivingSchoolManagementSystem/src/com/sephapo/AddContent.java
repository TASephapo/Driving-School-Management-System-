package com.sephapo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@MultipartConfig
public class AddContent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//initialize connection DB
		
		  Connection con;
		
		PrintWriter out = response.getWriter();
		Part part = request.getPart("document");
		String filename = part.getSubmittedFileName();
		
		String path = getServletContext().getRealPath("/"+"ImageFiles"+File.separator+filename);
		
		
		InputStream is = part.getInputStream();
		
	   	uploadfile(is,path);
	   	
	    try 
		   {
					  
	    				con = DatabaseConnection.initializeDatabase();
					
						
					    PreparedStatement st = con.prepareStatement("insert into content values (default,?,?,?)", Statement.RETURN_GENERATED_KEYS); 
					   
					 	 
						st.setString(1, (filename));
						st.setString(2, (request.getParameter("batch_id")));
						st.setString(3, (request.getParameter("comment")));
					
						st.executeUpdate();
						ResultSet tablekeys = st.getGeneratedKeys();
						tablekeys.next(); 
						st.close();
						
						   out.println("<html>");
						   out.println("<script language= 'javascript'>");
			               out.println(" alert('Content is successfully Uploaded')");
			               out.println(" </script>");
			               out.println("<meta http-equiv='refresh' content='0; URL=TutorDashbord.jsp'>");
			               out.println("<meta name='keywords' content='automatic redirection'>");
			               out.println("</html>");
						  
					  
				  }
				  catch (ClassNotFoundException e) 
				  {
						e.printStackTrace();
				  }
				   catch (SQLException e) 
				  {
					  
					  out.println("<html>");
					  out.println("<script language= 'javascript'>");
		              out.println(" alert('Content is not Uploaded please try again')");
		              out.println(" </script>");
		              out.println("<meta http-equiv='refresh' content='0; URL=TutorDashbord.jsp'>");
		              out.println("<meta name='keywords' content='automatic redirection'>");
		              out.println("</html>");					
		              e.printStackTrace();
					}
				
	    
	    
	   
	   /*
	    if(success)
	    {
	    	out.println("File uploaded to this directory : "+path);
	    }
	    else
	    {
	    	out.println("ERROR");
	    }
	    */
		
	}
	
	public boolean uploadfile(InputStream is, String path)
	{
		boolean test = false;
		
		try 
		{
			
			byte[] byt = new byte[is.available()];
			
			is.read();
			FileOutputStream fops = new FileOutputStream(path);
			fops.write(byt);
			fops.flush();
			fops.close();
			
			test = true;
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
			
		
		
		
		return test;
		
	}

}
