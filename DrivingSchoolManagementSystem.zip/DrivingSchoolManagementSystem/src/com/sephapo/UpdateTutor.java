package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class UpdateTutor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		Connection con;
		String  Tutor_id = request.getParameter("tutor_id");
		PrintWriter out = response.getWriter();
		
		try {
			
			
			 con = DatabaseConnection.initializeDatabase();
			
			
			
			String sql = "update Tutor set tutor_name=?,  phone=?, licence=?, vehile_type=?, salary=?, password=? where tutor_id='"+Tutor_id+"'";
			
			PreparedStatement st = con.prepareStatement(sql);
			
			
		
			
			st.setString(1, (request.getParameter("tutor_name")));
			st.setString(2, (request.getParameter("phone")));
			st.setString(3, (request.getParameter("licence")));
			st.setString(4, (request.getParameter("vehicle_type")));
			st.setString(5, (request.getParameter("salary")));
			st.setString(6, (request.getParameter("password")));
			

			st.executeUpdate();
			
			//Close all DB connections
			st.close();
	
			
			 out.println("<html>");
			 out.println("<script language= 'javascript'>");
             out.println(" alert('Tutor is successfully Updated!')");
             out.println(" </script>");
             out.println("<meta http-equiv='refresh' content='0; URL=AdminDashboard.jsp'>");
             out.println("<meta name='keywords' content='automatic redirection'>");
             out.println("</html>");
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			 
			 out.println("<html>");
			  out.println("<script language= 'javascript'>");
             out.println(" alert('Tutor is not Updated please try again')");
             out.println(" </script>");
             out.println("<meta http-equiv='refresh' content='0; URL=AdminDashboard.jsp'>");
             out.println("<meta name='keywords' content='automatic redirection'>");
             out.println("</html>");					
             e.printStackTrace();
		}
		
		
	}
		
}


