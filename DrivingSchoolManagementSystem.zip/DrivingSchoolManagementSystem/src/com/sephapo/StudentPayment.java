package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class StudentPayment extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		  PrintWriter out = response.getWriter();
		//initialize connection DB
			
		  Connection con;
		  
		  try 
		   {
					  con = DatabaseConnection.initializeDatabase();
					
						
					    PreparedStatement st = con.prepareStatement("insert into payment values (default,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS); 
					   
					 	 
						
						st.setString(1, (request.getParameter("payment")));
						st.setString(2, (request.getParameter("Account")));
						st.setString(3, (request.getParameter("Student_id")));
						st.setString(4, (request.getParameter("Fee")));
						st.setString(5, (request.getParameter("payDate")));
						
						st.executeUpdate();
						ResultSet tablekeys = st.getGeneratedKeys();
						tablekeys.next();
						st.close();
						
							
						   out.println("<html>");
						   out.println("<script language= 'javascript'>");
			               out.println(" alert('Payment is successful')");
			               out.println(" </script>");
			               out.println("<meta http-equiv='refresh' content='0; URL=AdminDashboard.jsp'>");
			               out.println("<meta name='keywords' content='automatic redirection'>");
			               out.println("</html>");
						  
					  
				  }
				  catch (ClassNotFoundException e) 
				  {
						e.printStackTrace();
				  }
				   catch (SQLException e) 
				  {
					  
					  out.println("<html>");
					  out.println("<script language= 'javascript'>");
		              out.println(" alert('Payment is not Successful please try again')");
		              out.println(" </script>");
		              out.println("<meta http-equiv='refresh' content='0; URL=AdminDashboard.jsp'>");
		              out.println("<meta name='keywords' content='automatic redirection'>");
		              out.println("</html>");					
		              e.printStackTrace();
					}
				
				
				
			}
		
	
	}


